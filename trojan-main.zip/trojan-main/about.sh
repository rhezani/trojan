#!/bin/bash
MYIP=$(wget -qO- ipinfo.io/ip);

clear
echo -e "=================================================" | lolcat
echo -e "#              Premium Auto Script              #"
echo -e "#-----------------------------------------------#"
echo -e "# For Debian 9 & Debian 10 64 bit               #"
echo -e "# For Ubuntu 18.04 & Ubuntu 20.04 64 bit        #"
echo -e "# For VPS with KVM and VMWare virtualization    #"
echo -e "# Build Up By WifiTROJAN                        #"
echo -e "#-----------------------------------------------#"
echo -e "# Thanks To                                     #"
echo -e "#-----------------------------------------------#"
echo -e "#                                               #"
echo -e "# Allah                                         #"
echo -e "# My Family                                     #"
echo -e "# Google                                        #"
echo -e "#-----------------------------------------------#"
echo -e "=================================================" | lolcat
